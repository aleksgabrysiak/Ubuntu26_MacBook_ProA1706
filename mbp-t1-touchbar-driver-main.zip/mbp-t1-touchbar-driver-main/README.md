# Apple iBridge Touch Bar Driver

This repository contains the out-of-tree driver for the MacBook Pro T1 touch bar and related iBridge devices.

## Overview

This project includes the following Linux kernel modules:

- `apple_ibridge` — core iBridge support
- `apple_ib_tb` — touch bar driver
- `apple_ib_als` — ambient light sensor driver

In addition, we provide a helper script, a `systemd` service, and a module blacklist to ensure the touch bar binds correctly to `apple_ib_tb`.

## 1. Build

From the repository root:

```bash
cd /mbp-t1-touchbar-driver-main
make
```

## 2. Install

Install the modules to the kernel module tree:

```bash
sudo make install
```

If your system uses initramfs, update it after installation:

```bash
sudo update-initramfs -u
```

## 3. Deploy supporting files

Copy the helper script, service unit, and blacklist to the proper system locations:

```bash
sudo cp apple-ib-touchbar-rebind.sh /usr/local/bin/
sudo cp apple-ib-touchbar.service /etc/systemd/system/
sudo cp apple-ib-touchbar-blacklist.conf /etc/modprobe.d/
sudo chmod +x /usr/local/bin/apple-ib-touchbar-rebind.sh
```

## 4. Configure module blacklist

The blacklist file prevents conflicting HID/ALS drivers from loading automatically (already copied in step 3.):

```conf
blacklist hid_sensor_hub
blacklist hid_sensor_als
blacklist apple_ib_als
```

## 5. Enable the systemd service

Reload systemd, then enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable apple-ib-touchbar.service
sudo systemctl start apple-ib-touchbar.service
```

The service is defined as `Type=oneshot`, so it runs once at boot and finishes.

## 6. How the helper script works

The script performs these steps:

1. Removes conflicting modules if loaded:
   - `hid_sensor_hub`
   - `hid_sensor_als`
   - `apple_ib_als`
2. Loads `apple_ibridge`
3. Loads `apple_ib_tb`
4. Rebinds the USB device on bus `1-3`

This ensures the touch bar receives the correct HID interface and avoids the `0302` conflict.

## 7. Manual testing

Run the helper manually when needed:

```bash
sudo /usr/local/bin/apple-ib-touchbar-rebind.sh
```

If the touch bar is already working, this is useful after rebuilding and reinstalling the modules.

## 8. Verify status

Check service status with:

```bash
systemctl status apple-ib-touchbar.service
```

A healthy state should show:

- `Loaded: loaded ... enabled`
- `Active: inactive (dead)`
- `status=0/SUCCESS`

Also verify the loaded modules:

```bash
lsmod | grep -E 'apple_ib_tb|apple_ibridge|apple_ib_als|hid_sensor_hub|hid_sensor_als'
```

Expected result:

- `apple_ib_tb` loaded
- `apple_ibridge` loaded
- `hid_sensor_hub`, `hid_sensor_als`, `apple_ib_als` not loaded

## 9. Notes

- If you rebuild the drivers, repeat `make`, `sudo make install`, and optionally `sudo update-initramfs -u`.
- If the touch bar stops working after a reboot, run the helper script again.
- If you want to restore ALS support, remove or modify the blacklist file.
