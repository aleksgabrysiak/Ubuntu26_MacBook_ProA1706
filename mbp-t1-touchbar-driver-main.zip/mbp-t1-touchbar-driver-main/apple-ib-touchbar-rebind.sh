#!/bin/bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root."
  exit 1
fi

MODULES=(hid_sensor_hub hid_sensor_als apple_ib_als apple_ib_tb apple_ibridge)
for mod in "${MODULES[@]}"; do
  if lsmod | grep -q "^${mod}[[:space:]]"; then
    echo "Removing module: $mod"
    modprobe -r "$mod" || true
  fi
done

echo "Loading apple_ibridge and apple_ib_tb"
modprobe apple_ibridge
modprobe apple_ib_tb

if [[ -w /sys/bus/usb/drivers/usb/unbind ]]; then
  echo "1-3" > /sys/bus/usb/drivers/usb/unbind
fi

if [[ -w /sys/bus/usb/drivers_probe ]]; then
  echo "1-3" > /sys/bus/usb/drivers_probe
fi

echo "apple-ib-touchbar rebind complete."
